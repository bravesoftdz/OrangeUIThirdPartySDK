//
//  IOSpeScaleLayoutButton.h
//  AipOcrSdk
//
//  Created by Yan,Xiangda on 2017/2/22.
//  Copyright © 2017年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IOSpeScaleLayoutButton : UIButton

@end
