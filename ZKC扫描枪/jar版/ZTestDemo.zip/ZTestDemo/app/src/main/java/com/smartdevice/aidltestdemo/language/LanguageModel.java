package com.smartdevice.aidltestdemo.language;

/**
 * Created by leoxu on 2017/4/17.
 */

public class LanguageModel {
    public String language;
    public int code;
    public String description;
}
