package com.smartdevice.aidltestdemo.printer.entity;

public class GoodsInfo {

	public String goods_name;
	public String goods_unit_price;
	public String goods_amount;
	public String goods_price;
}
